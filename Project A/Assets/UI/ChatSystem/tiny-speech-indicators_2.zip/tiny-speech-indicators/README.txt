Tiny Speech Indicators By @rehhouari / @pigeonivy

CC0 License: https://creativecommons.org/share-your-work/public-domain/cc0/