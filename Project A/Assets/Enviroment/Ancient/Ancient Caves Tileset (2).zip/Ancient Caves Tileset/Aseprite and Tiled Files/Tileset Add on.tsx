<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Tileset Add on" tilewidth="16" tileheight="16" tilecount="576" columns="24">
 <image source="Tileset Add on.png" width="384" height="384"/>
</tileset>
